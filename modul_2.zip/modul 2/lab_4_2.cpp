#include <stdio.h>

int main() {
    int size;

    printf("Enter matrix size (2 or 3): ");
    scanf("%d", &size);

    if (size != 2 && size != 3) {
        printf("Invalid size! Please enter 2 or 3.\n");
        return 1;
    }

    int a[3][3], b[3][3], sum[3][3], product[3][3];

    printf("Enter elements of first matrix:\n");
    for (int i = 0; i < size; i++)
        for (int j = 0; j < size; j++)
            scanf("%d", &a[i][j]);

    printf("Enter elements of second matrix:\n");
    for (int i = 0; i < size; i++)
        for (int j = 0; j < size; j++)
            scanf("%d", &b[i][j]);

    for (int i = 0; i < size; i++)
        for (int j = 0; j < size; j++)
            sum[i][j] = a[i][j] + b[i][j];

    printf("\nAddition Result:\n");
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++)
            printf("%d ", sum[i][j]);
        printf("\n");
    }

    if (size == 3) {
        for (int i = 0; i < size; i++)
            for (int j = 0; j < size; j++) {
                product[i][j] = 0;
                for (int k = 0; k < size; k++)
                    product[i][j] += a[i][k] * b[k][j];
            }

        printf("\nMultiplication Result:\n");
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++)
                printf("%d ", product[i][j]);
            printf("\n");
        }
    }

    return 0;
}

