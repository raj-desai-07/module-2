#include<stdio.h>
int main(){
	char choice;
	int n1, n2;
	
	printf("Enter Number 1 : ");
	scanf("%d", &n1);
	
	printf("Enter Number 2 : ");
	scanf("%d", &n2);
	
	printf("\n\n+ for Addition\n- for Substraction\n* for Multiplication\n/for Division\n\n");
	
	printf("Enter Your Choice : ");
	scanf(" %c", &choice);
	
	switch(choice)
	{
		case '+':
			printf("Addition of two Number is : %d", n1+n2);
			break;
		case '-':
			printf("Substraction of two Number is : %d", n1-n2);
			break;
		case '*':
			printf("Multiplication of two Number is : %d", n1*n2);
			break;
		case '/':
			printf("Division of two Number is : %d", n1/n2);
			break;
		default:
			printf("Invalid Choice..!");
			break;
	}
	
	return 0;
}
