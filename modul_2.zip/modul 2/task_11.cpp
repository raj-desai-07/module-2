#include<stdio.h>
#include<string.h>
int main(){
	char str1[100], str2[100];
	
	printf("Enter String 1 : ");
	gets(str1);
	
	printf("Enter String 2 : ");
	gets(str2);
	
	strcat(str1, str2);
	
	printf("\n\n");
	puts(str1);
	
	printf("\n\nLenght of Concatinated String is : %d", strlen(str1));
	
	return 0;
}
