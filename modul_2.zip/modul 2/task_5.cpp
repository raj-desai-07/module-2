#include<stdio.h>
int main(){
	int num;
	
	printf("Enter One Number : ");
	scanf("%d", &num);
	
	if(num % 2 == 0)
	{
		printf("Enterd number is even");
	}
	else{
		printf("Enterd number is odd");
	}

	printf("\n\n");
	
	switch(num)
	{
		case 1:
			printf("January");
			break;
		case 2:
			printf("February");
			break;
		case 3:
			printf("March");
			break;
		case 4:
			printf("April");
			break;
		case 5:
			printf("May");
			break;
		case 6:
			printf("June");
			break;
		case 7:
			printf("July");
			break;
		case 8:
			printf("Augest");
			break;
		case 9:
			printf("Suptember");
			break;
		case 10:
			printf("October");
			break;
		case 11:
			printf("November");
			break;
		case 12:
			printf("December");
			break;
		default:
			printf("Invalid Choice for Find Month(Hint : Enter 1 to 12)");
			break;
	}
	
	return 0;
}
