#include<stdio.h>
int main(){
	int n, sum = 0;
	
	printf("Please Enter How Many Numbers You Want : ");
	scanf("%d", &n);
	
	int arr[n];
	
	for(int i = 0; i < n; i++)
	{
		printf("Enter Number %d : ", i+1);
		scanf("%d", &arr[i]);
		sum += arr[i];
	}
	printf("\n\nTotal Sum of All Number is : %d\n\n", sum);
	
	printf("The Reverse Order is : -->\t");
	for(int i = n-1; i >= 0; i--)
	{
		printf("%d\t", arr[i]);		
	}
	
	return 0;
}
