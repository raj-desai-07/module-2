#include<stdio.h>
int main(){
	
	FILE *fptr;
	fptr = fopen("my_text.txt", "w");
	
	if(fptr != NULL)
	{
		char str[5000];
		printf("Enter Some Text Hear : ");
		fgets(str, 5000, stdin);
		
		fprintf(fptr, "%s", str);
		
		fclose(fptr);
		fptr = fopen("my_text.txt", "r");
		char ch;
		ch = fgetc(fptr);
		
		while(ch != EOF)
		{
			printf("%c", ch);
			ch = fgetc(fptr);
		}
	}
	
	return 0;
}
