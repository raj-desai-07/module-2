#include<stdio.h>
int main(){
	int a, b;
	
	printf("Enter First Number : ");
	scanf("%d", &a);
	
	printf("Enter Second Number : ");
	scanf("%d", &b);
	
	printf("\n\nFirst number is : %d , second number is : %d", a, b);
	
//	arithmatic op

	printf("\n\nAddition of 2 numbers is : %d", a+b);
	printf("\nsubstraction of 2 numbers is : %d", a-b);
	printf("\nmultiplication of 2 numbers is : %d", a*b);
	printf("\nDivision of 2 numbers is : %d\n\n", a/b);
	
	if(a > b)
	{
		printf("A : %d is Grater", a);
	}
	else{
		printf("B : %d is Grater", b);
	}
	
	return 0;
}
