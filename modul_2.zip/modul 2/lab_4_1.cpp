#include<stdio.h>
int main()
{
    int n = 10, small, large, temp;
    int arr[n];
    
    for (int i = 0; i < n; i++)
    {
        printf("Enter Value of %d'th Index : ", i);
        scanf("%d", &arr[i]);
    }
    
    small = arr[0];
    large = arr[0];
    
    for (int i = 0; i < n; i++)
    {
        if (small > arr[i])
		{
			small = arr[i];
		}
        if (large < arr[i])
		{
			large = arr[i];
		}
    }
    
//    sorting loop
    for (int i = 0; i < n; i++)
    {
        for (int j = i + 1; j < n; j++)
        {
            if (arr[i] > arr[j])
            {
                temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
    }
    
    printf("\nSmallest Number is : %d", small);
    printf("\nLargest Number is : %d", large);
    
    printf("\nArray in Ascending Order: ");
    for (int i = 0; i < n; i++)
    {
        printf("%d ", arr[i]);
    }
    
    return 0;
}

