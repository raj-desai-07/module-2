#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<time.h>
int main()
{
	
	srand(time(0));

	int num,u_num;
	num= rand()%100+1;
//	printf("%d\n",num);
	
	printf("\n\n\t\t\t\t\tNOTE : Guess the Number Between 1 to 100\n\n");
	
	do{
		printf("Guess Number : ");
		scanf("%d", &u_num);
		
		if(u_num == num)
		{
			printf("\n\t\t\t\t\tWohhhhhhhhho..!You Guess Correct Number");
		}
		else if(u_num > num)
		{
			printf("\nPlease Guess Smaller One..!");
		}
		else if(u_num < num)
		{
			printf("\nPlease Guess Bigger One..!");
		}
		else{
			break;
		}
		
	}while(u_num != num);
	
	return 0;

}
