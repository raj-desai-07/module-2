#include<stdio.h>
#include<string.h>
struct student{
	char name[100];
	int roll;
	int marks1, marks2, marks3;
};
int main(){
	
	struct student stu[10];
	
	strcpy(stu[0].name, "Raj Desai");
	stu[0].roll = 1;
	stu[0].marks1 = 70;
	stu[0].marks2 = 80;
	stu[0].marks3 = 90;
	
	strcpy(stu[1].name, "Niyati");
	stu[1].roll = 2;
	stu[1].marks1 = 90;
	stu[1].marks2 = 80;
	stu[1].marks3 = 70;
	
	strcpy(stu[2].name, "Bhavy");
	stu[2].roll = 3;
	stu[2].marks1 = 90;
	stu[2].marks2 = 90;
	stu[2].marks3 = 90;
	
//	printing all recordes
	printf("Name is : %s\n", stu[0].name);
	printf("Roll is : %d\n", stu[0].roll);
	printf("Mark1 is : %d\n", stu[0].marks1);
	printf("Mark2 is : %d\n", stu[0].marks2);
	printf("Mark3 is : %d\n", stu[0].marks3);
	printf("\n\n");
	
	printf("Name is : %s\n", stu[1].name);
	printf("Roll is : %d\n", stu[1].roll);
	printf("Mark1 is : %d\n", stu[1].marks1);
	printf("Mark2 is : %d\n", stu[1].marks2);
	printf("Mark3 is : %d\n", stu[1].marks3);
	printf("\n\n");
	
	printf("Name is : %s\n", stu[2].name);
	printf("Roll is : %d\n", stu[2].roll);
	printf("Mark1 is : %d\n", stu[2].marks1);
	printf("Mark2 is : %d\n", stu[2].marks2);
	printf("Mark3 is : %d\n", stu[2].marks3);
	printf("\n\n");
	
	return 0;
}
