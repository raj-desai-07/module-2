#include <stdio.h>
#include <math.h>

int main() {
    int n;
    printf("Enter a number: ");
    scanf("%d", &n);

    int original = n, sum = 0, digits = 0, temp = n;

    while (temp != 0) {
        digits++;
        temp /= 10;
    }

    temp = n;
    while (temp != 0) {
        int digit = temp % 10;
        sum += pow(digit, digits);
        temp /= 10;
    }

    if (sum == original) {
        printf("%d is an Armstrong number.\n", n);
    } else {
        printf("%d is not an Armstrong number.\n", n);
    }

    printf("\nArmstrong numbers between 1 and 1000 are:\n");

    for (int i = 1; i <= 1000; i++) {
        int num = i, digit_count = 0, total = 0, copy = i;

        while (copy != 0) {
            digit_count++;
            copy /= 10;
        }

        copy = i;
        while (copy != 0) {
            int d = copy % 10;
            total += pow(d, digit_count);
            copy /= 10;
        }

        if (total == num) {
            printf("%d ", num);
        }
    }

    return 0;
}
