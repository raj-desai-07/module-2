#include <stdio.h>

int main() {
    char str[200];
    int v = 0, c = 0, d = 0, s = 0;

    printf("Enter a string: ");
    fgets(str, sizeof(str), stdin);

    for (int i = 0; str[i] != '\0'; i++) {
        char ch = str[i];

        if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z')) {
            if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u' ||
                ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U') {
                v++;
            } else {
                c++;
            }
        } else if (ch >= '0' && ch <= '9') {
            d++;
        } else if (ch != ' ' && ch != '\n') {
            s++;
        }
    }

    printf("\nVowels: %d\n", v);
    printf("Consonants: %d\n", c);
    printf("Digits: %d\n", d);
    printf("Special Characters: %d\n", s);

    return 0;
}

