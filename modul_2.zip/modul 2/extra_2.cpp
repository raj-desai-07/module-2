#include <stdio.h>

int main() {
    int rows, i, j, k, num;

    printf("Enter number of rows: ");
    scanf("%d", &rows);

    for (i = 0; i < rows; i++) {
        for (k = 0; k < rows - i - 1; k++) {
            printf("  ");
        }

        num = 1;
        for (j = 0; j <= i; j++) {
            printf("%4d", num);
            num = num * (i - j) / (j + 1);
        }
        printf("\n");
    }

    return 0;
}
