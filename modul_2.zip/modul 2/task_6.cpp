#include<stdio.h>
int main(){
	
//	for loop
	printf("Using For Loop...\n\n");
	for(int i = 1; i <= 10; i++)
	{
		printf("%d\t", i);
	}
	
	printf("\n\nUsing While Loop...\n\n");
	int i = 1;
	while(i <= 10)
	{
		printf("%d\t", i);
		i++;
	}
	
	printf("\n\nUsing Do-While Loop...\n\n");
	i = 1;
	do{
		printf("%d\t", i);
		i++;
	}while(i <= 10);
	
	return 0;
}
