#include <stdio.h>

int fibonacci(int n);
void printFibonacci(int limit);

int main() {
    int num;
    printf("Enter a number: ");
    scanf("%d", &num);

    printf("Fibonacci Series up to %d: ", num);
    printFibonacci(num);

    return 0;
}

int fibonacci(int n) {
    if (n <= 1)
        return n;
    return fibonacci(n - 1) + fibonacci(n - 2);
}

void printFibonacci(int limit) {
    int i = 0, fib;
    while (1) {
        fib = fibonacci(i);
        if (fib > limit)
            break;
        printf("%d ", fib);
        i++;
    }
}

