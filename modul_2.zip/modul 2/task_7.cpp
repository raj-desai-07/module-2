#include<stdio.h>
int main(){
	for(int i = 1; i <=10; i++)
	{
		if(i == 3)
		{
			continue;
		}
		if(i == 5)
		{
		printf("%d\n", i);

			break;
		}
		else{
			printf("%d\n", i);

		}
	}
	
	return 0;
}
