#include<stdio.h>
int main(){
	int arr[10], multi[100][100], sum = 0;
	
	for(int i = 0; i < 5; i++)
	{
		printf("Enter Value of arr[%d] : ", i);
		scanf("%d", &arr[i]);
	}
	
	printf("\n\n");
	
	for(int i = 0; i < 5; i++)
	{
		printf("at arr[%d] The Value is : %d\n", i, arr[i]);
	}
	
//	two daimentional Array( 3 X 3 )

	printf("\n\nUsing two daimentional Array( 3 X 3 )\n\n");
	
	for(int i = 0; i < 3; i++)
	{
		for(int j = 0; j < 3; j++)
		{
			printf("Enter Value of Arr[%d][%d] : ", i, j);
			scanf("%d", &multi[i][j]);
		}
	}
	
	printf("\n\n");
	
	for(int i = 0; i < 3; i++)
	{
		for(int j = 0; j < 3; j++)
		{
			printf("%d ", multi[i][j]);
			sum += multi[i][j];
		}
		printf("\n");
	}
	
	printf("\n");
	
	printf("Total sum of All Elements is : %d", sum);
	
	return 0;
}
