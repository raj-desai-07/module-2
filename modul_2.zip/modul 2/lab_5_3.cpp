#include <stdio.h>
#include <string.h>

int numPal(int n) {
    int o = n, r = 0, d;
    while (n != 0) {
        d = n % 10;
        r = r * 10 + d;
        n /= 10;
    }
    return o == r;
}

int strPal(char s[]) {
    int i = 0, j = strlen(s) - 1;
    while (i < j) {
        if (s[i] != s[j])
            return 0;
        i++;
        j--;
    }
    return 1;
}

int main() {
    int c;
    printf("1.Num Palindrome\n2.Str Palindrome\n");
    scanf("%d", &c);

    if (c == 1) {
        int n;
        printf("Enter num: ");
        scanf("%d", &n);
        if (numPal(n))
            printf("Palindrome\n");
        else
            printf("Not Palindrome\n");
    } 
    else if (c == 2) {
        char s[100];
        printf("Enter str: ");
        scanf("%s", s);
        if (strPal(s))
            printf("Palindrome\n");
        else
            printf("Not Palindrome\n");
    } 
    else {
        printf("Invalid Choice\n");
    }

    return 0;
}

