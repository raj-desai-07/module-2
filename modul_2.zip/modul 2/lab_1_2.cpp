#include<stdio.h>
int main(){
	int n;
	
	printf("Enter One Number : ");
	scanf("%d", &n);
	
//	even or odd
	if(n % 2 == 0)
	{
		printf("\nThe Number is Even..!");
	}
	else{
		printf("\nThe Number is Odd..!");
	}
	
//	positive, nagative, or Zero

	if(n > 0)
	{
		printf("\nThe Number is Positive..!");
	}
	else if(n == 0)
	{
		printf("\nThe Number is 0..!");
	}
	else{
		printf("\nThe Number is Nagative..!");
	}
	
//	divide by 3 or 5
	if(n % 3 == 0 || n % 5 == 0)
	{
		printf("\nThe Number is Devided by 3 or 5..!");
	}
	else{
		printf("\nThe Number is Not Devided by 3 or 5..!");
	}
	
	return 0;
}
