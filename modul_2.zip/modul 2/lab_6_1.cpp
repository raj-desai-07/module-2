#include <stdio.h>

void reverse(char s[]);

int main() {
    char str[100];

    printf("Enter a string: ");
    scanf("%s", str);

    reverse(str);

    printf("Reversed string: %s\n", str);

    return 0;
}

void reverse(char s[]) {
    int len = 0;
    while (s[len] != '\0') {
        len++;
    }

    for (int i = 0, j = len - 1; i < j; i++, j--) {
        char temp = s[i];
        s[i] = s[j];
        s[j] = temp;
    }
}

