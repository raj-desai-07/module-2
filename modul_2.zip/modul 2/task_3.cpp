#include<stdio.h>
int main(){
	int num = 10;
	float pi = 7.14;
	char ch = 'n';
	
	printf("Num(Inteiger) is : %d\n", num);
	printf("Pi(Float) is : %f\n", pi);
	printf("Ch(Charector) is : %c", ch);
	
	return 0;
}
