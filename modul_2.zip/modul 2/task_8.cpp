#include<stdio.h>
int fact(int num);
int main(){
	
	int num;
	
	printf("Enter Number to find Factoriyal : ");
	scanf("%d", &num);
	
	printf("\nThe Factoriyal is : %d", fact(num));
	
	return 0;
}

int fact(int num){
	if(num == 0)
	{
		return 1;
	}
	int factnm1 = fact(num - 1);
	int factn = factnm1 * num;
	return factn;
}
