#include <stdio.h>
#include <string.h>

int main() {
    char str[200];
    char longest[200] = "";
    int i = 0, len = 0, maxLen = 0, wordCount = 0;

    printf("Enter a sentence: ");
    fgets(str, sizeof(str), stdin);

    while (str[i] != '\0') {
        if (str[i] != ' ' && str[i] != '\n') {
            len++;
        } else {
            if (len > 0) {
                wordCount++;
                if (len > maxLen) {
                    maxLen = len;
                    strncpy(longest, &str[i - len], len);
                    longest[len] = '\0';
                }
                len = 0;
            }
        }
        i++;
    }

    if (len > 0) {
        wordCount++;
        if (len > maxLen) {
            maxLen = len;
            strncpy(longest, &str[i - len], len);
            longest[len] = '\0';
        }
    }

    printf("\nTotal Words: %d\n", wordCount);
    printf("Longest Word: %s\n", longest);

    return 0;
}

