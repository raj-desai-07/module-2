#include<stdio.h>
int main()
{
	int age = 20;
	int *ptr = &age;
	
	printf("Age before update value : %d", age);
	*ptr = 22;
	printf("\nAge after update value : %d", age);
	
	return 0;
}
