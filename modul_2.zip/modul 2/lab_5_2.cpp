#include <stdio.h>

int factorialRecursive(int n);
int factorial(int n);

int main() {
    int num;
    printf("Enter a number: ");
    scanf("%d", &num);

    int recursiveResult = factorialRecursive(num);
    int iterativeResult = factorial(num);

    printf("\nFactorial of %d (Recursive): %d", num, recursiveResult);
    printf("\nFactorial of %d (Normal): %d\n", num, iterativeResult);

    return 0;
}

int factorialRecursive(int n) {
    if (n <= 1)
        return 1;
    return n * factorialRecursive(n - 1);
}

int factorial(int n) {
    int result = 1;
    for (int i = 1; i <= n; i++) {
        result *= i;
    }
    return result;
}
