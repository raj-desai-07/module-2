#include<stdio.h>
int main(){
	int n, sum = 0;
	float avg = 0;
	
	printf("Enter Number of Element for Array : ");
	scanf("%d", &n);
	
	int arr[n];
	
	for(int i = 0; i < n; i++)
	{
		printf("Enter Value at %d'th Index : ");
		scanf("%d", &arr[i]);
		sum += arr[i];
	}
	
	printf("\n\nSum of All %d Elements is %d : \n\n",n, sum);
	avg = sum / n;
	printf("Avrage of all Elements is : %f", avg);
	
	return 0;
}
